# %%
import open3d as o3d
import numpy as np
import cv2

# Don't show the debug information
o3d.utility.set_verbosity_level(o3d.utility.VerbosityLevel.Error)

img = cv2.imread("occhiali.png")
print("img shape: ", img.shape)

import numpy as np

# Generazione di 5000 punti (x, y, z) casuali in [0, 1]
points = np.random.rand(10000, 3)
print("points shape: ", points.shape)
center_of_mass = np.mean(points, axis=0)
print("center_of_mass: ", center_of_mass)
distance_from_center = np.linalg.norm(points - center_of_mass, axis=1)

# Colorazione dei punti in base alla distanza dal centro
colors = np.zeros((10000, 3))
colors[:, :] = distance_from_center.reshape(-1, 1)


pcd = o3d.geometry.PointCloud()
pcd.points = o3d.utility.Vector3dVector(points)
pcd.colors = o3d.utility.Vector3dVector(colors)

# Creazione del sistema di riferimento
mesh_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.6, origin=[0, 0, 0])
o3d.visualization.draw_geometries([pcd, mesh_frame])


import open3d as o3d
bob = o3d.io.read_triangle_mesh("bob/bob_tri.obj", True)
bob.paint_uniform_color([0.8, 0.7, 0.1])

o3d.visualization.draw([bob])


print("Vertices:")
print(np.asarray(bob.vertices))
print("\n\nTriangles:")
print(np.asarray(bob.triangles))



bob = o3d.io.read_triangle_mesh("bob/bob_tri.obj", True)
bob.paint_uniform_color([0.8, 0.7, 0.1])
bob.compute_triangle_normals()

o3d.visualization.draw_geometries([bob])

# # Estensione ai vertici della mesh


bob = o3d.io.read_triangle_mesh("bob/bob_tri.obj", True)

vertices = np.asarray(bob.vertices)

bob_pcd = o3d.geometry.PointCloud()
bob_pcd.points = o3d.utility.Vector3dVector(vertices)

o3d.visualization.draw_geometries([bob_pcd])

# # Estimate vertex normals

print(vertices.shape)
# compute bounding box
min_bound = vertices.min(axis=0)
max_bound = vertices.max(axis=0)
print("min_bound", min_bound)
print("max_bound", max_bound)

# compute max distance between two points
diameter = np.linalg.norm(max_bound - min_bound)
print("diameter", diameter)


bob_pcd.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=1, max_nn=20))
# change points size in visualization
o3d.visualization.draw_geometries([bob_pcd])


central_pcd = o3d.io.read_point_cloud("center.ply")
o3d.visualization.draw_geometries([central_pcd])

# # ICP - Iterative Closest Point


# Artificial example 


# Apply ICP to align the two point clouds

threshold = 0.5


def get_random_transformation():
    x_rot = np.random.rand()*2*np.pi
    y_rot = np.random.rand()*2*np.pi
    z_rot = np.random.rand()*2*np.pi
    translation = np.random.rand(3)-1
    rot_matrix = o3d.geometry.get_rotation_matrix_from_xyz((x_rot, y_rot, z_rot))

    transformation = np.eye(4)
    transformation[:3, :3] = rot_matrix
    transformation[:3, 3] = translation

    return transformation

def flip_180_around_x():
    transformation = np.eye(4)
    transformation[1, 1] = -1
    transformation[2, 2] = -1

    return transformation

# apply ICP to align the two point clouds and visualize step by step

def draw_registration_result(source, target, transformation):
    source_temp = source.transform(transformation)
    o3d.visualization.draw_geometries([source_temp, target])

def step_by_step_ICP(pcd2, pcd):
    threshold = 0.5
    initial_transformation = np.eye(4)
    for i in range(15):
        reg_p2p = o3d.pipelines.registration.registration_icp(pcd2, pcd, threshold, initial_transformation, 
                                                        o3d.pipelines.registration.TransformationEstimationPointToPoint(),
                                                        o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=10))
        draw_registration_result(pcd2, pcd, reg_p2p.transformation)
        initial_transformation = reg_p2p.transformation



# Load a mesh and sample from it to create a point cloud
bob = o3d.io.read_triangle_mesh("bob/bob_tri.obj", True)

sampled = bob.sample_points_poisson_disk(number_of_points=10000)
sampled.paint_uniform_color([0.8, 0.7, 0.1])

o3d.visualization.draw_geometries([sampled])


pcd = sampled
pcd2 = o3d.geometry.PointCloud()
pcd2.points = pcd.points
pcd2.paint_uniform_color([0.1, 0.1, 0.7])
pcd2.transform(get_random_transformation())

o3d.visualization.draw_geometries([pcd, pcd2])

step_by_step_ICP(pcd2, pcd)


pcd3 = bob.sample_points_poisson_disk(number_of_points=2000)
pcd3.paint_uniform_color([0.1, 0.1, 0.7])
pcd3.transform(get_random_transformation())

o3d.visualization.draw_geometries([pcd, pcd3])


step_by_step_ICP(pcd3, pcd)


